
<?php
session_start();
 include("header.php");

 $user_login = @$_SESSION['login_user_id'];
  $login_session= @$_SESSION['login_user'];
  $user = @$_GET['user'];
   if (!isset($_SESSION['login_user'])) {
    header("location: Login.php");
}
  
 
 ?>

<div class="container">
 <div class="row">
  <div class="col-12">
  <br><br><br>
<?php if(!empty($login_session)){ ?><b id="welcome">Welcome : <i><?php echo ucfirst($login_session); ?></i></b><?php } ?>
    <h3 class="h3">shopping now </h3>
	</div></div>
    <div class="row">

<?php
$sql = "SELECT * FROM products";
$result = $conn->query($sql);
// $result = mysqli_query("SELECT * FROM 'products'");
while($row = mysqli_fetch_assoc($result)){
?> <div class="col-md-3 col-sm-6">
            <div class="product-grid4">
			<form method="post" action="cart.php?user=<?php echo $user;?>">
			  <input type='hidden' name='code' value="<?php echo $row['code'] ?>" />
			  <input type='hidden' name='image' value="<?php echo $row['image'] ?>" />
			  <input type='hidden' name='prodct_name' value="<?php echo $row['prodct_name'] ?>" />
			  <input type='hidden' name='price' value="<?php echo $row['p_price'] ?>" />
                <div class="product-image4 image">

					    <img class="pic-1" src="image/<?php echo $row['image']; ?>"><img class="pic-2" src="image/<?php echo $row['image']; ?>">

                    <span class="product-new-label">New</span>
                </div>
                <div class="product-content">
                    <h3 class="title name"><?php echo $row['prodct_name']; ?></h3>
                    <div class="price">
                        $ <?php echo $row['p_price']; ?>
                    </div>
					 <input type='hidden' name='qty' value="1" /><input type='hidden' name='ID' value="<?php echo $row['id']; ?>" />
                    <button type='submit' name="addtocart" class='buy'>Add To Cart</button>
                </div>
            </div></form>
        </div>



    <?php    }

?>

<div style="clear:both;"></div>



    </div>
</div>
</body>
</html>
