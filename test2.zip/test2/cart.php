<?php
session_start();
include('config.php');




   $user1 = @$_GET['user'];
  $user_login = @$_SESSION['login_user_id'];
  $val = $_SESSION['login_user'];
  

 $total='';
   $login_session= @$_SESSION['login_user'];
if(isset($_POST['addtocart'])){
 $name = $_POST['prodct_name'];
 $code = $_POST['code'];
  $price = $_POST['price'];
 $qty = $_POST['qty'];
$image = $_POST['image'];
if($login_session !='' && $user1 ="login" ){

 $total = floatval($total) + (floatval($price)-(((floatval($price)*floatval($qty))*15)/100));
}
elseif($login_session !='' && $user1 ="register" ){

 $total += ($price-((($price*$qty)*1)/100));
}else{

 $total = floatval($total) + floatval($price)* floatval($qty);
}
 $pro_id = $_POST['ID'];
 echo $user1;
if($login_session !='' && ($user1 ="login" || $user1 ="register" )){

         $queryType = "select type,id from user where username='".$login_session."' limit 1";
        $resultType = mysqli_query($conn, $queryType);
        $count = mysqli_num_rows($resultType);
        $rows = mysqli_fetch_array($resultType);

			if($count !=''){

		$update ='INSERT INTO `cartdetails`( `productid`,  `pro_name`,`pimage` ,`cartqty`, `price`, `userid`, `usertype`, `procode`, `users`)
			 VALUES ("'.$pro_id .'","'.$name.'","'. $image.'","'. $qty.'","'. $total .'","'. $rows['id'].'","'. $rows['type'].'","'. $code.'","'. $val.'")';
	  $updateresult = mysqli_query($conn, $update);
	  if($updateresult){
header('Location: home.php');
}}}
elseif($login_session =='' && $user1 ="guest" ){

  $queryType = "select * from user where id='".$user_login."' && user_type = '". $user1."' limit 1";
        $result = mysqli_query($conn, $queryType);
        if($result)
        {
            $count = mysqli_num_rows($result);
        }
        else{
          $count = 0;
        }
      //  $rows = mysql_fetch_array($resultType);

			if($count != 0){

		$update ='INSERT INTO `cartdetails`( `productid`,  `pro_name`,`pimage` ,`cartqty`, `price`, `userid`, `usertype`, `procode`, `users`)
			 VALUES ("'.$pro_id .'","'.$name.'","'. $image.'","'. $qty.'","'. $total .'","'. $user_login.'","'.  $user1.'","'. $code.'","'. $user1.'")';
	  $updateresult = mysql_query($update);
	  if($updateresult){
header('Location: home.php');}
}


}}
 ?>
