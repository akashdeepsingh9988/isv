<style>

.div-top
{
    margin-top: 100px;
    font-size: 30px;
    text-align: center;
}
</style>

<?php 
session_start();
$status = $_GET["status"];
$email= $_SESSION["user_email"];
//echo 'email ='.$email;

if($status == "pass")
{

?>
<div class = "div-top">
    <img src = "image/success.png"><br>
    Order Successfully placed.
</div>
<?php 

}
else
{
?>
<div class = "div-top">
    <img src = "image/failed.png"><br>
    Order failed. please try again later.
</div>

<?php

}
?>
<br>
<br>
<br>
<br>

<div style="text-align: center;">
<a href = "home.php" > Go To Main Page </a>
</div>
<?php 
?>