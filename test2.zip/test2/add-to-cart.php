<?php
$code = "";
$user = "";
session_start();
include('config.php');

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    
} else if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $code = $_POST["code"];
    $user = $_GET["user"];
    $name = $_POST['prodct_name'];
    $price = $_POST['price'];
    $qty = $_POST['qty'];


// INSERTING VALUES IN DATABASE

    if ($code != null && $user != "") {

        $sql = "INSERT INTO cartdetails (productid, pro_name,cartqty, price,userid) VALUES ($code, '$name', $qty, $price, '$user')";

        if ($conn->query($sql) === TRUE) {
          
            header("Location: home.php");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        $conn->close();
    }

    // INSERTTION CLOSE
   
}
?>

</body>
</html>