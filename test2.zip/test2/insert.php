<?php
include("config.php");

// Check insert functions
$table_name = 'user';
//$db = connect();
if(isset($_POST['insert'])){
  $query = $_POST['insertQuery'];
$q = mysql_query( $query);
if($q){
echo "successful";
header('Location:admin.php');
}else{
echo "Error in query";
}

}
if(isset($_POST['Back'])){
header('Location:admin.php');
}
?>
<html>
    <head>
        <title>Insert</title>
</head>
<body class="container">
    <h1>Insert Data<h2>
        <br/>
        <form method="POST">
            <textarea name="insertQuery" rows="5" cols="150" value="Mickey">INSERT INTO <?php echo $table_name;?> ( <?php $i = 0;
	 $query = 'select * from '.$table_name;

$result = mysql_query($query);
$s = '';
	while ($i < mysql_num_fields($result))
	{
		$meta = mysql_fetch_field($result, $i);
		 $s .=$meta->name .',';
		$i = $i + 1;
	}
	echo substr($s, 0, -1);?>) VALUES (<?php $v ='';for($j=1;$j<=mysql_num_fields($result);$j++){ $v .="'value'".',';}echo substr($v, 0, -1);?>)</textarea>
            <br/>
            <input class="btn btn-primary" type = "submit" name="insert" value="Insert">
            <input class="btn btn-danger" type = "submit" name="Back" value="Back">
</form>
</body>

</html>
