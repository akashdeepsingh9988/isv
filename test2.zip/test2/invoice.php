<?php
session_start();
require_once('config.php');

     $user_login = @$_SESSION['login_user_id'];

	$status='';
include('header.php');
?>
<div class="container">
<br><br><br>
	<div class="row">
	  <table class="table">
	  	<tr>
	  		<td></td>
	  		<th>Item Name</th>
	  		<th>Price</th>
			<th>Quantity</th>
	  	</tr>

<?php

 $name='';$total_quantity ='';$price='';

	$sql_count = mysqli_query($conn, "SELECT * FROM `cartdetails`   WHERE  userid='".$user_login."'" );
	  $count1 =mysqli_num_rows($sql_count);
if($count1!=0){

while ( $product = mysqli_fetch_array($sql_count)){
	 $total_quantity = floatval($total_quantity) + floatval($product["cartqty"]);

	$price = floatval($price) + floatval($product["price"]);

    $name =$product["pro_name"];

?>
	<tr>
		<td>
<img src='image/<?php echo $product["pimage"]; ?>' width="50" height="40" />
</td>

		<td><?php echo $product["pro_name"]; ?></td>
		<td>$ <?php echo $product["price"]; ?></td>
		<th><?php echo $product["cartqty"];
				?></th>
	</tr><?php

	}

	if(isset($_POST['checkout'])){
		$order_name = $_POST['order_name'];
        $order_price = $_POST['order_price'];
		$order_qty = $_POST['order_qty'];

		$user_data = "select * from user where id='".$user_login ."' limit 1";
		$result_user_data = mysqli_query($conn,$user_data);
		$result_user_data= mysqli_fetch_array($result_user_data);
		$to = 'ishavkumar786@gmail.com';//$result_user_datas['email'];
			$subject = "Ordered Product";
			$txt = "<html>
<head>
<title>Ordered Successful</title>
</head>
<body>
<h3>Hello ".ucfirst($result_user_data['name'])."</h3><br><br><p>Your product has Successfully order.</p><table  class='table'>
<tr>
<th>Product Name:</th>
<th>Product Quantity :</th>
<th>Price : </th>
</tr><tr>
<td>".ucfirst($order_name)."</td>
<td>".$order_qty."</td>
<td>$".$order_price."</td>
</tr>
</table></body>
</html>";
			// $headers = "MIME-Version: 1.0" . "\r\n";
			// $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
      //
			// $headers = "From: webmaster@example.com" . "\r\n" .
			// "CC: somebodyelse@example.com";
      //
			// if(mail($to,$subject,$txt,$headers)){
			// 	$status= "mail is send to ".$to."<br>".$txt;
			 //if($users =='guest'){
			 //if(session_destroy()){
			header("Refresh: 300;  login.php");
			//}
			 //}
			//else{ echo "error";}
    }}






				?>

<tr><td><strong>Total Price</strong></td>
	<td><strong>$<?php echo $price; ?></strong></td>
	<?php if(	$status ==''){?>
        <td><form method="post" action="checkout.php">
			<input  name="order_name"  class="form-control" type="hidden" value="<?php echo $name; ?>">
			<input  name="order_price"  class="form-control" type="hidden" value="<?php echo $price; ?>">
			<input  name="order_qty"  class="form-control" type="hidden" value="<?php echo  $total_quantity; ?>">
                        <button type="submit" class="btn btn-info">Checkout</button></form></td>
	<?php }else{ ?><td><p><?php echo $status;?></p></td><?php } ?>
	</tr>
	</table>
	</div>
  </div>
  </body></html>
