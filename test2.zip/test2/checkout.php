


<?php
session_start();
if (isset($_SESSION['login_user'])) {
    
    $val = $_SESSION['login_user'];

    //echo $guests;
    ?>

    <!DOCTYPE html>
    <html>
        <head>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
            <link rel="stylesheet" href="css/checkout.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
            <script src="jquery/jquery.creditCardValidator.js"></script>

        </head>
        <body>
            
            <h1 style="font-size: 50px; padding: 20px;">Checkout</h1>
            <div class="row">
                <div class="col-75" style="text-align: left;">
                    <div class="container">
                        <form action="sendmail.php" method = "post">

                            <div class="row">
                                <div class="col-50">
                                    <h3>Billing Address</h3>
                                    <label for="fname"><i class="fa fa-user"></i> Full Name</label>
                                    <input type="text" id="fname" name="firstname" required="true" placeholder="Enter your name">
                                    <label for="phone"><i class="fa fa-envelope"></i> Phone</label>
                                    <input type="text" id="email" name="email" required="true" placeholder="+1012346789">
                                    <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
                                    <input type="text" id="adr" name="address" required="true" placeholder="Street Address">
                                    <label for="city"><i class="fa fa-institution"></i> City</label>
                                    <input type="text" id="city" name="city" required="true" placeholder="City">

                                    <div class="row">
                                        <div class="col-50">
                                            <label for="state">State</label>
                                            <input type="text" id="state" name="state" required="true" placeholder="State">
                                        </div>
                                        <div class="col-50">
                                            <label for="zip">Postal Code</label>
                                            <input type="text" id="zip" pattern="[a-zA-Z][0-9][a-zA-Z](-| |)[0-9][a-zA-Z][0-9]" name="postal" required="true" placeholder="Postal Code ">
                                        </div>
                                    </div>
                                </div>

                                <div class="col-50">
                                    <h3>Payment</h3>
                                    <label for="fname">Accepted Cards</label>
                                    <div class="icon-container">
                                        <i class="fa fa-cc-visa" style="color:navy;"></i>
                                        <i class="fa fa-cc-amex" style="color:blue;"></i>
                                        <i class="fa fa-cc-mastercard" style="color:red;"></i>
                                        <i class="fa fa-cc-discover" style="color:orange;"></i>
                                    </div>
                                    <label for="cname">Name on Card</label>
                                    <input type="text" id="cname" name="cardname" required="true" placeholder="Enter your name">
                                    <label for="ccnum">Credit card number</label>
                                    <input type="text" id="ccnum" name="cardnumber" required="true" minlength="16" maxlength="16" placeholder="Card Number">
                                    <label for="expmonth">Exp Month</label>
                                    <input type="text" id="expmonth" name="expmonth" required="true" placeholder="Expiry Month">
                                    <div class="row">
                                        <div class="col-50">
                                            <label for="expyear">Exp Year</label>
                                            <input type="text" id="expyear" name="expyear" required="true" placeholder="Expiry year">
                                        </div>
                                        <div class="col-50">
                                            <label for="cvv">CVV</label>
                                            <input type="password" id="cvv" name="cvv" required="true" placeholder="CVV Number">
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <label style="text-align: center;">
                                <input type="hidden" id="roomd" name="roomd" value="<?php echo $val?>">
                             

                                <input type="submit" value="Continue to checkout" class="btn">
                            </label>
                        </form>
                    </div>
                </div>
            </div>

        </body>
    </html>



    <?php
} else {
    header("Location: Login.php");
}
?>


    <script src="jquery/checkout.js"></script>
<script>
    $(function () {
        $('#ccnum').validateCreditCard(function (result) {
            $('.log').html('Card type: ' + (result.card_type === null ? '-' : result.card_type.name)
                    + '<br>Valid: ' + result.valid
                    + '<br>Length valid: ' + result.length_valid
                    + '<br>Luhn valid: ' + result.luhn_valid);

            if (result.valid === false)
            {
                return false;
            } else
            {
                return true;
            }


        });


    });
</script>

<style>


input[type=email] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}
input[type=password] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}
</style>
