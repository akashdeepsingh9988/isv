<?php
session_start();
$email = $_SESSION['user_email'];
$to = $email;
$subject = "Order Confirmation";
$txt = "Ordered  by  : .$email.";
$headers = "From: admin@onlineshop.com";

mail($to, $subject, $txt, $headers);

include 'config.php';

$sql = "DELETE FROM cartdetails WHERE users = '$email'";

if ($conn->query($sql) === TRUE) {
    header("location: order-status.php?status=pass");
} else {
    echo "Error deleting record: " . $conn->error;
}
$conn->close();
?>