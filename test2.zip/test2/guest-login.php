<?php

  include("config.php");
  session_start();
  $val  = $_POST['guest_email'];
    $_SESSION['login_user']= $val;  
    //echo $val;
    header("location: home.php?user=".$val);
  ?>