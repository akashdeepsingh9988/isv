<?php
include("config.php");
session_start();
if (isset($_SESSION['login_user'])) {
    header("Location:home.php");
}

$error = ''; // Variable To Store Error Message

if (isset($_POST['submit'])) {
    if (empty($_POST['userName']) || empty($_POST['password'])) {
        $error = "Username or Password is invalid";
    } else {

        $uname = $_POST['userName'];
        $password = $_POST['password'];
        $pro_code1 = $_POST['pro_code'];
        $qty = 1;
        $query = "select * from user where username='" . $uname . "'and password='" . $password . "' limit 1";

        $result = mysqli_query($conn, $query);

        $queryType = "select type,id,email from user where username='" . $uname . "'and password='" . $password . "' limit 1";
        $resultType = mysqli_query($conn, $queryType);
        $count = mysqli_num_rows($resultType);
        $rows = mysqli_fetch_array($resultType);

        $_SESSION['login_user'] = $uname;
        $_SESSION['login_user_id'] = $rows["id"];
        $_SESSION['user_email'] = $rows["email"];

        if (($count >= 1) && ($rows["type"] == 'admin')) {
            echo "Successful";
            session_start();
            $_SESSION['login_user_id'] = $rows["id"];
            $_SESSION['login_user'] = $uname;
            $_SESSION['code'] = $pro_code1;
            $_SESSION['user_email'] = $rows["email"];

            header('Location: http://localhost/test2/Admin.php');
        } else if (($count >= 1) && ($rows["type"] == 'customer')) {
            session_start();
            echo "Login Successful.";
            $_SESSION['code'] = $pro_code1;
            $_SESSION['login_user'] = $uname;
            $_SESSION['login_user_id'] = $rows["id"];
            $_SESSION['user_email'] = $rows["email"];
            header("Location:http://localhost/test2/home.php?user=login");
            exit();
        } else {
            echo "Not Registered Yet";
        }
    }
}
include("header.php");
?>

<div class="container container1">
    <br>
    <center><h2 class="heading"><b><img src = "image/login.png" style="width:230px; height: 60px;"></b></h2></center><br>
    <div class="login-form">
        <div class="main-div">
            <div class="panel">
            </div>
            <form id="Login" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">

                <div class="form-group">

                    <input type="hidden" name="pro_code" value="<?php echo $pro_code; ?>">
                    <input type="text" class="form-control" id="inputEmail"  name="userName" placeholder="Enter UserName">

                </div>

                <div class="form-group">

                    <input type="password" class="form-control" name="password" id="inputPassword" placeholder="**********" >

                </div>
                <input  name="p_code"  class="form-control"  type="hidden" value="<?php echo $pro_code; ?>">
                <input type="submit" style="width: 100%; height: 45px;"  name="submit" value="Login" class="btn btn-primary"><br><br>
                <span><?php echo $error; ?></span>
            </form>

            <a href="registration.php?user=register" style="width: 100%; height: 40px;" class="btn btn-primary" type = "submit" >Register </a>
            <br>
            <br>
            <a href="guest.php?user=guest" style="width: 100%; border: 0px; height: 40px;"  class="btn btn-primary" type = "submit" >Countinue as Guest</a>
        </div>

    </div></div></div>

</body>
</html>

<style>
    .login-form{
        width:350px;
        margin:auto;
    }
</style>


