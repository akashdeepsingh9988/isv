<?php

    $host="localhost";
    $user="root";
    $password="root";
    $db="b2c";

    $conn =  mysqli_connect($host,$user,"root",$db);
	if($conn !=""){
	//echo "connection set up.";
	}else{ echo "error";}
  // $dbcheck = mysqli_select_db($db);
	// 	if (!$dbcheck) {
  //       	echo mysql_error();
	// 	}

        ?>
