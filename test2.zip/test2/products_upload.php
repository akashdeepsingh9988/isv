<?php 
include("config.php");
session_start();
$output='';
$user_check = @$_SESSION['login_user'];
$ses_sql = mysql_query("select username from users where username='$user_check'");
$row = mysql_fetch_assoc($ses_sql);
$login_session = $row['username'];
if(!empty($user_check)){

 $btn = @$_GET['queries'];

        if ($btn == "Admin") {
            header('Location: Admin.php');
        } else if ($btn == "Product List"){
            header('Location: products_upload.php');
        }else if ($btn == "Logout"){
            header('Location: logout.php');
        }

			$target_dir = "image/";
		 if(isset($login_session) && isset($_POST['product_submit'])) {
			$product_name = $_POST['product_name'];
			$quantity = $_POST['quantity'];
			 $price = $_POST['price'];
			 $code = $_POST['code'];
			 $description = $_POST['description'];  
			 $product_image = $_FILES["product_image"]["name"] ;
		
			$target_file = $target_dir . basename($_FILES["product_image"]["name"]);
				$uploadOk = 1;
				$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
				    $check = getimagesize($_FILES["product_image"]["tmp_name"]);
					if($check !== false) {
						if(move_uploaded_file($_FILES["product_image"]["tmp_name"], $target_file)) 
						{
					//	echo "successful";
						} 
						else 
						{
						echo "Error !!";
						}
					//echo "File is an image - " . $check["mime"] . ".";
					$uploadOk = 1;
				} else {
				//	echo "File is not an image.";
					$uploadOk = 0;
				}  

      $query = 'INSERT INTO products(prodct_name,description,image,p_price,p_quantity,code) VALUES ("'.$product_name.'","'.$description.'","'.$product_image.'","'.$price.'","'.$quantity.'","'. $code.'")';
        
        //$queryType = "select type from users where username='".$uname."'and password='".$password."' limit 1";
        $resultType = mysql_query($query);
		
        if($resultType){
		$output=  "successful uploaded";
		
		}
     
    }
	
?>
<!DOCTYPE html>

<html>
<head>
    
    <title>Product</title>
    <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/bootstrap-theme.css" rel="stylesheet">
</head>
<body class="container">
 <form method="GET" >
    <br/>
	
<input class="btn btn-primary" type = "submit" name="queries" value="Admin">
<input class="btn btn-primary" type = "submit" name="queries" value="Product List">
<input class="btn btn-danger" type = "submit" name="queries" value="Logout">
<br/>
<br/>
 </form>
 <div>

 <!---heading---->
    <form class="form-horizontal" enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post"  id="product_form">
<fieldset>

<!-- Form Name -->
<legend><center><h2 class="heading"><b>upload product</b></h2></center></legend><br>


	<!---Form starting----> 
<?php echo $output;?>
	 <!--- For Product Name---->
         <div class="col-sm-12 formtetxt">
             <div class="row">
			     <div class="col-xs-4">
          	         <label class="firstname control-label">Product Name :</label> </div>
		         <div class="col-xs-8 inputGroupContainer">
					<div class="input-group">
					  <input  name="product_name" placeholder="Product Name" class="form-control" id="pname" type="text">
					</div>
		            
             </div>
		      </div>
		 </div>
		 <input  name="code" value="<?php rand ( 10000 , 99999 );?>" class="form-control" id="pname" type="hidden">
		  <!-----------For Quantity-------->
		<div class="col-sm-12 formtetxt">
		         <div class="row">
				     <div class="col-xs-4" >
		 	              <label class="phone control-label">Quantity :</label></div>
				  <div class="col-xs-8 inputGroupContainer" >
					    	<div class="input-group">
						       <input name="quantity" class="form-control" type="number">
						</div>
				 </div>
          </div>
		  </div>
	 		
     <!-----For price---->
		 <div class="col-sm-12 formtetxt">
		     <div class="row">
			     <div class="col-xs-4">
		             <label class="mail  control-label" >Price(in $) :</label></div>
			     <div class="col-xs-8 inputGroupContainer"	>	 
			           <div class="input-group">
							
							<input name="price" placeholder="Add Product Price" class="form-control"  type="text">
					</div>
		         </div>
		     </div>
		 </div>
	 <!-----For upload product image---->
          <div class="col-sm-12 formtetxt">
		         <div class="row">
				     <div class="col-xs-4">
		 	              <label class="pass control-label">Upload Image :</label></div>
				  <div class="col-xs-8 inputGroupContainer">
			            <div class="input-group">
						  <input name="product_image" id="product_image" class="form-control"  type="file">
						</div>
				 </div>
          </div>
		  </div>
		  
		 
		  <!-------Product Description ----------------------->
		  <div class="col-sm-12 formtetxt">
		         <div class="row">
				     <div class="col-xs-4">
		 	              <label class="pass control-label"> Product Description  :</label></div>
				  <div class="col-xs-8 inputGroupContainer">
			             <div class="input-group">
							    <textarea  name="description" placeholder="Enter your product description" class="form-control rounded-0" id="exampleFormControlTextarea1" rows="3"></textarea>
						</div>
				 </div>
          </div>
		  </div>
		  		<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-4"><br>
    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type="submit" name="product_submit" value="SUBMIT" class="btn btn-warning" >&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
  </div>
</div>
</fieldset>
</form>  




 <h2>Product Listing</h2>
    <?php 

  $query1 = "SELECT * FROM products";
 $resultType1 = mysql_query($query1);
?>   
<div class="row">
<div class="col-1"></div>
<div class="col-10">
  <table class="table">
    <thead>
      <tr>
        <th>ID</th>
        <th>Product Name</th>
        <th>Description</th>
		<th>Images</th>
		<th>Price of Product</th>
		<th>Quantity of product</th>
		<th>Action</th>
      </tr>
    </thead>
    <tbody>
	<?php
	if (mysql_num_rows($resultType1 )> 0) {
    // output data of each row
	//print_r($resultType->fetch_assoc());
    while($row = mysql_fetch_array($resultType1)) {
?>
      <tr>
	   <td><?php echo $row['id']; ?></td>
       <td><?php echo $row['prodct_name']; ?></td>
       <td><?php echo $row['description']; ?></td>
	    <td><img class="pic-1" src="image/<?php echo $row['image']; ?>" height="50px" width="50px"></td>
	   <td><?php echo $row['p_price']; ?></td>
	    <td><?php echo $row['p_quantity']; ?></td>
        <td><?php echo '<a href="update_my.php?update_id='.$row['id'].'&table_name=products">Update</a>/ <a href="delete.php?product_id='.$row['id'].'&delete=product">Delete</a></td>';?>
      </tr>
	  <?php 
}
}?>
    
    </tbody>
  </table>
  </div>
  <div class="col-1">
  </div>
  </div>
</div>
</div>
</body>		
</html>
	 <?php } ?>